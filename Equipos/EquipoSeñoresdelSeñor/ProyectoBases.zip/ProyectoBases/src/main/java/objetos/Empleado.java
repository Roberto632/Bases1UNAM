/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author armir
 */
public class Empleado {
    
int num_empleado;
    String rfc;
    String edad;
    String sueldo;
    String fecha_nacimiento;
    String nombre;
    String ap_pat;
    String ap_mat;
    String calle;
    String numero_domicilio;
    String colonia;
    String cod_postal;
    String estado;
    String telefono;

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
    
    

    public Empleado(int num_empleado, String rfc, String edad, String sueldo, String fecha_nacimiento, String nomrbe, String ap_pat, String ap_mat, String calle, String numero_domicilio, String colonia, String cod_postal, String estado) {
        this.num_empleado = num_empleado;
        this.rfc = rfc;
        this.edad = edad;
        this.sueldo = sueldo;
        this.fecha_nacimiento = fecha_nacimiento;
        this.nombre = nomrbe;
        this.ap_pat = ap_pat;
        this.ap_mat = ap_mat;
        this.calle = calle;
        this.numero_domicilio = numero_domicilio;
        this.colonia = colonia;
        this.cod_postal = cod_postal;
        this.estado = estado;
    }
    
    public Empleado(){
        
    }
    

    public int getNum_empleado() {
        return num_empleado;
    }

    public void setNum_empleado(int num_empleado) {
        this.num_empleado = num_empleado;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getSueldo() {
        return sueldo;
    }

    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nomrbe) {
        this.nombre = nomrbe;
    }

    public String getAp_pat() {
        return ap_pat;
    }

    public void setAp_pat(String ap_pat) {
        this.ap_pat = ap_pat;
    }

    public String getAp_mat() {
        return ap_mat;
    }

    public void setAp_mat(String ap_mat) {
        this.ap_mat = ap_mat;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero_domicilio() {
        return numero_domicilio;
    }

    public void setNumero_domicilio(String numero_domicilio) {
        this.numero_domicilio = numero_domicilio;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCod_postal() {
        return cod_postal;
    }

    public void setCod_postal(String cod_postal) {
        this.cod_postal = cod_postal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
}

