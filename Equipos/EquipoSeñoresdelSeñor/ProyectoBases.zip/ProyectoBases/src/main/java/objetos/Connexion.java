/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author armir
 */
public class Connexion {

    Connection con;
    String url = "jdbc:postgresql://ep-solitary-tree-14942843.us-east-2.aws.neon.tech/neondb";
    String usuario = "neon";
    String clave = "2qtDvKBiu1oU";

    public Connection Conexion() {
        try {
            // Descomenta esta línea si estás utilizando una versión antigua de JDBC
            // Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(url,usuario,clave);

            // Verificar la conexión ejecutando una consulta simple
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT VERSION()");
            if (resultSet.next()) {
                System.out.println("Conexión exitosa. Versión de la base de datos: " + resultSet.getString(1));
            }

        } catch (SQLException ex) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, e);
        }

        return con;
    }



}
