/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author armir
 */
public class funcionesDB {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Connexion cx = new Connexion();


    public static Connection conexion() throws SQLException  {
        String host = "jdbc:postgresql://ep-solitary-tree-14942843.us-east-2.aws.neon.tech/neondb";
        String usuario = "neon";
        String contra = "2qtDvKBiu1oU";
        Connection con = DriverManager.getConnection(host, usuario, contra);
        return con;

    }

    public Empleado infoEmpleados( int numero_empleado) throws FileNotFoundException, IOException, SQLException {
        String host = "jdbc:postgresql://ep-solitary-tree-14942843.us-east-2.aws.neon.tech/neondb";
        String usuario = "neon";
        String contra = "2qtDvKBiu1oU";
        Connection con = DriverManager.getConnection(host, usuario, contra);
        Empleado emp = new Empleado();
        con=cx.Conexion();
        String consulta = "SELECT * FROM empleado WHERE num_empleado = ? ";
        
        
        emp.setNum_empleado(numero_empleado);
        try {
            ps = con.prepareStatement(consulta);
            ps.setInt(1, numero_empleado);

            rs = ps.executeQuery();
            rs.next();
            do {
                emp.setNum_empleado((rs.getInt("num_empleado")));
                emp.setRfc((rs.getString("rfc")));
                emp.setEdad(rs.getString("edad"));
                emp.setSueldo(rs.getString("sueldo"));
                emp.setFecha_nacimiento(rs.getString("fecha_nacimiento"));
                byte[] fotoBytes = rs.getBytes("foto");
                if (fotoBytes != null) {
                    foto(fotoBytes, "C:\\Users\\armir\\OneDrive\\Documentos\\EDA2\\ProyectoBases\\src\\main\\webapp\\assets\\img", "hollu.jpg");
                    //foto(fotoBytes, "C:\\Users\\armir\\hollu.jpg", "hollu.jpg");
                
                }
                emp.setNombre((rs.getString("nombre")));
                emp.setAp_pat((rs.getString("ap_pat")));
                emp.setAp_mat((rs.getString("ap_mat")));
                emp.setCalle((rs.getString("calle")));
                emp.setNumero_domicilio((rs.getString("numero_domicilio")));
                emp.setColonia((rs.getString("colonia")));
                emp.setCod_postal((rs.getString("cod_postal")));
                emp.setEstado((rs.getString("estado")));

            } while (rs.next());
            
        String consultaTelefonos="SELECT telefono FROM telefono WHERE num_empleado_empleado = ?";
        ps = con.prepareStatement(consultaTelefonos);
        ps.setInt(1, numero_empleado);

        rs = ps.executeQuery();
        rs.next();
            do {
                emp.setTelefono((rs.getString("telefono")));
            } while (rs.next());
        
            
            
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }
        return emp;
    }

    public void foto(byte[] fotoBytes, String directorio, String nombreArchivo) throws IOException {
        //File pic = new File("juka.jpg");
        try (FileOutputStream fos = new FileOutputStream(directorio + "/" + "hollu.jpg")) {
            //try (FileOutputStream fos = new FileOutputStream( "holluk.jpg")) {

            fos.write(fotoBytes);
        }
    }

}
